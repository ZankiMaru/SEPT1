Tutorial Info:
Tutor: Aditya Jagtap
Session: 5:30pm Wednesday

Group Members:
s3494185 - Benjamin Lee 	- 25%
s3496982 - Reyham Soenasto	- 25%
s3323595 - Yohanes Keanoe	- 25%
s3381108 - Steven Bui		- 25%

Github Link:
https://github.com/rmit-s3494185-ben-lee/SEPT1.git

Design Pattern Used:
MVC