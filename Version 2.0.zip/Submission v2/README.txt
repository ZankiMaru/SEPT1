Tutorial Info:
Tutor: Aditya Jagtap
Session: 5:30pm Wednesday

Group Members:
s3494185 - Benjamin Lee 	- 25%
s3496982 - Reyham Soenasto	- 25%
s3323595 - Yohanes Keanoe	- 25%
s3381108 - Steven Bui		- 25%

Github Link:
https://github.com/rmit-s3494185-ben-lee/SEPT1.git

Design Pattern Used:
MVC
Architecture is divided between the back-end(model) and view-controller(view).
This type of architecture made it more straightforward to divide tasks needed
to complete functional requirements.

What was changed/added in the code:
- New class ForecastDayData
- New class ForecastInterval
- New class Factory; contains getDataOpenweather() and getDataForecast()
- New class GraphPanel
- New method getForecastData() in Station class
- New method selectSite in MainMenu class
- New variable String site in Model class
- New JTabbedpanel in StationView class
- New logging implemented throughout classes

Notes:
-Log output is found in console output.